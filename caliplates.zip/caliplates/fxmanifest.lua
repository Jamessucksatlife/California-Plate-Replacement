fx_version 'cerulean'
game 'gta5'

author 'James Carson'
description 'California License Plates Pack (runtime texture replacement)'
version '1.0.0'

client_scripts {
    'client.lua'
}

files {
    'images/*.png',
    'README.md'
}

lua54 'yes'
