-- California Plates runtime replacement
-- Replaces GTA's vehshare plate textures for everyone (NPCs + players)

local plateMap = {
    -- GTA's common plate textures inside vehshare.ytd
    -- We map five core slots. If your server uses more, duplicate lines accordingly.
    -- plate01: Blue on White 1  -> California Standard
    { oldTxd = 'vehshare', oldTxn = 'plate01', newTxd = 'caliplates', newTxn = 'ca_plate_standard' },
    -- plate02: Blue on White 2  -> California Sunset
    { oldTxd = 'vehshare', oldTxn = 'plate02', newTxd = 'caliplates', newTxn = 'ca_plate_sunset' },
    -- plate03: Yellow on Blue   -> CA Legacy Blue
    { oldTxd = 'vehshare', oldTxn = 'plate03', newTxd = 'caliplates', newTxn = 'ca_plate_legacy_blue' },
    -- plate04: Yellow on Black  -> CA Legacy Black
    { oldTxd = 'vehshare', oldTxn = 'plate04', newTxd = 'caliplates', newTxn = 'ca_plate_legacy_black' },
    -- plate05: SA Exempt        -> CA Exempt
    { oldTxd = 'vehshare', oldTxn = 'plate05', newTxd = 'caliplates', newTxn = 'ca_plate_exempt' },
}

local function replacePlates()
    local txd = CreateRuntimeTxd('caliplates')

    -- Create runtime textures from our images
    CreateRuntimeTextureFromImage(txd, 'ca_plate_standard', 'images/ca_plate_standard.png')
    CreateRuntimeTextureFromImage(txd, 'ca_plate_sunset', 'images/ca_plate_sunset.png')
    CreateRuntimeTextureFromImage(txd, 'ca_plate_legacy_blue', 'images/ca_plate_legacy_blue.png')
    CreateRuntimeTextureFromImage(txd, 'ca_plate_legacy_black', 'images/ca_plate_legacy_black.png')
    CreateRuntimeTextureFromImage(txd, 'ca_plate_exempt', 'images/ca_plate_exempt.png')

    -- Replace vehshare textures globally
    for _, m in ipairs(plateMap) do
        AddReplaceTexture(m.oldTxd, m.oldTxn, m.newTxd, m.newTxn)
    end
end

CreateThread(function()
    replacePlates()
    -- Re-apply after resource restart/hard swaps
    Wait(1000)
    replacePlates()
end)
